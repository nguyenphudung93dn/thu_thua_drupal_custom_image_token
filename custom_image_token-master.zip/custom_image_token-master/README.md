# custom_image_token
Create custom image token in drupal 8
